let time = 0;
function game(dt){
   cn.image(images["Background"], 0, 0, 128, 72);
   time += 0.005 * dt;
   for(var i = 0; i < 6; i ++){
      cn.image(images["GroundDice" + floor(time) % 7 + "-" + i], 2 + i * 14, 2, 14, 14);
   }
}