createCanvas(1280, 720);
cn = createGraphics(128, 72);
let canvas = document.querySelector("canvas");
let ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;
cn.noStroke();
noStroke();
frameRate(0);
let lastUpdate = Date.now();

draw = () => {
   var now = Date.now();
   var dt = now - lastUpdate;
   lastUpdate = now;

   game(dt);

   image(cn, 0, 0, 1280, 720);

   fill(255, 255, 255);
   rect(0, 0, 60, 20);
   fill(0, 0, 0);
   text((1000/dt).toFixed(1) + " fps", 5, 15);
}