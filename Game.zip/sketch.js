const main = new Main();

draw = () => {
   main.update();
   main.display();
}